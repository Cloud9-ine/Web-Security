const { op } = require('./utils');

console.log(op(process.argv[2]));
process.exit();
