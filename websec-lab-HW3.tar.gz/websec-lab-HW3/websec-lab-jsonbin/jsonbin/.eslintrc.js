module.exports = Object.assign(require('@remy/eslint/node'), {});
